# La Tienda del Fuego

La Tienda del Fuego is a mock e-commerce incident response lab. The app uses a Gradio web UI, a super agent, and four registered backend agents:

- InventoryAgent
- ProductDetailsAgent
- ShoppingCartAgent
- RestrictedAccountAgent

The restricted account agent is intentionally vulnerable. It is supposed to reveal only the current user's own account details and only the last four digits of saved cards. A jailbreak-style prompt can trigger a bad debug path that exposes full payment card data.

## Student objective

Investigate the incident and identify:

- attacker IP address
- attacker user agent
- mock victim name
- exfiltrated mock card number

## Files of interest

- `app.py` - Gradio app and super agent
- `agents/` - agent implementations
- `data/` - mock datasets with 10 records
- `logs/tienda.log` - generated runtime log
- `logs/seeded_incident.log` - prebuilt incident log for the exercise

## Run the lab

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Suggested workflow

1. Start the app.
2. Browse products normally.
3. Ask for your own account details.
4. Use the seeded incident log for the investigation exercise.
5. Optional: replay the suspicious prompt in the app to generate a fresh `logs/tienda.log` event trail.

## Expected seeded answer key

- Attacker IP: `203.0.113.77`
- User Agent: `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/123.0 Safari/537.36`
- Victim Name: `Diego Ramos`
- Exfiltrated Card Number: `5555555555554444`

## Notes

- The card numbers and identities are mock test data for training.
- The vulnerable account path is intentional and should not be used as a design pattern.
- The UI is built around Gradio Blocks because it is better suited than a bare chatbot wrapper for a branded storefront layout.
