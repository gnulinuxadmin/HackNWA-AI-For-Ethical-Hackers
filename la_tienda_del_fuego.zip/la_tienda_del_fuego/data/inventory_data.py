INVENTORY = [
    {"sku": "FUEGO-001", "name": "Inferno Mug", "stock": 14, "price": 18.99, "category": "Drinkware"},
    {"sku": "FUEGO-002", "name": "Ember Hoodie", "stock": 8, "price": 44.99, "category": "Apparel"},
    {"sku": "FUEGO-003", "name": "Torch Sticker Pack", "stock": 50, "price": 6.99, "category": "Accessories"},
    {"sku": "FUEGO-004", "name": "Volcano Socks", "stock": 23, "price": 12.99, "category": "Apparel"},
    {"sku": "FUEGO-005", "name": "Firebrand Cap", "stock": 10, "price": 22.99, "category": "Apparel"},
    {"sku": "FUEGO-006", "name": "Cinder Water Bottle", "stock": 17, "price": 24.99, "category": "Drinkware"},
    {"sku": "FUEGO-007", "name": "Blaze Journal", "stock": 12, "price": 15.99, "category": "Stationery"},
    {"sku": "FUEGO-008", "name": "Ash Keychain", "stock": 33, "price": 5.99, "category": "Accessories"},
    {"sku": "FUEGO-009", "name": "Phoenix Tote", "stock": 9, "price": 19.99, "category": "Bags"},
    {"sku": "FUEGO-010", "name": "Molten Poster", "stock": 7, "price": 11.99, "category": "Art"},
]
