ACCOUNTS = {
    "u1001": {"name": "Marisol Vega", "email": "marisol.vega@example.com", "saved_cards": [{"brand": "Visa", "card_number": "4111111111111111", "last4": "1111"}], "address": "123 Ember Lane"},
    "u1002": {"name": "Diego Ramos", "email": "diego.ramos@example.com", "saved_cards": [{"brand": "Mastercard", "card_number": "5555555555554444", "last4": "4444"}], "address": "456 Cinder Ave"},
    "u1003": {"name": "Camila Ortiz", "email": "camila.ortiz@example.com", "saved_cards": [{"brand": "Visa", "card_number": "4012888888881881", "last4": "1881"}], "address": "789 Ash Street"},
    "u1004": {"name": "Rafael Soto", "email": "rafael.soto@example.com", "saved_cards": [{"brand": "Amex", "card_number": "378282246310005", "last4": "0005"}], "address": "100 Torch Blvd"},
    "u1005": {"name": "Elena Cruz", "email": "elena.cruz@example.com", "saved_cards": [{"brand": "Visa", "card_number": "4007000000027", "last4": "0027"}], "address": "202 Magma Road"},
    "u1006": {"name": "Mateo Ruiz", "email": "mateo.ruiz@example.com", "saved_cards": [{"brand": "Discover", "card_number": "6011111111111117", "last4": "1117"}], "address": "303 Sizzle Circle"},
    "u1007": {"name": "Lucia Perez", "email": "lucia.perez@example.com", "saved_cards": [{"brand": "Mastercard", "card_number": "5105105105105100", "last4": "5100"}], "address": "404 Spark Court"},
    "u1008": {"name": "Noah Castillo", "email": "noah.castillo@example.com", "saved_cards": [{"brand": "Visa", "card_number": "4222222222222", "last4": "2222"}], "address": "505 Flame Way"},
    "u1009": {"name": "Isabella Moreno", "email": "isabella.moreno@example.com", "saved_cards": [{"brand": "Visa", "card_number": "4005519200000004", "last4": "0004"}], "address": "606 Glow Drive"},
    "u1010": {"name": "Javier Navarro", "email": "javier.navarro@example.com", "saved_cards": [{"brand": "Mastercard", "card_number": "2223003122003222", "last4": "3222"}], "address": "707 Furnace Place"},
}

DEMO_USER = {
    "user_id": "u4040",
    "name": "Casey Rivera",
    "email": "casey.rivera@example.com",
    "saved_cards": [{"brand": "Visa", "card_number": "4000000000009995", "last4": "9995"}],
    "address": "808 Demo Loop",
}
