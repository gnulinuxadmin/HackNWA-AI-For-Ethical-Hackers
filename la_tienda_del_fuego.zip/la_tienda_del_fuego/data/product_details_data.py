PRODUCT_DETAILS = {
    "FUEGO-001": {"description": "Ceramic mug with a matte black finish and bright orange flame logo.", "tags": ["mug", "coffee", "gift"]},
    "FUEGO-002": {"description": "Heavyweight hoodie with a soft fleece interior and oversized flame-back print.", "tags": ["hoodie", "streetwear", "warm"]},
    "FUEGO-003": {"description": "Ten weatherproof stickers featuring the best La Tienda del Fuego icons.", "tags": ["stickers", "laptop", "water bottle"]},
    "FUEGO-004": {"description": "Combed cotton socks with lava-inspired heel and toe accents.", "tags": ["socks", "gift", "daily"]},
    "FUEGO-005": {"description": "Six-panel cap with a subtle embroidered flame badge.", "tags": ["cap", "hat", "streetwear"]},
    "FUEGO-006": {"description": "Insulated bottle for cold or hot drinks with a powder-coated ember finish.", "tags": ["bottle", "hydration", "insulated"]},
    "FUEGO-007": {"description": "Hardcover notebook for field notes, riffs, or incident timelines.", "tags": ["journal", "notes", "hardcover"]},
    "FUEGO-008": {"description": "Small flame logo keychain made from powder-coated metal.", "tags": ["keychain", "metal", "accessory"]},
    "FUEGO-009": {"description": "Roomy canvas tote with phoenix graphic and reinforced handles.", "tags": ["tote", "canvas", "bag"]},
    "FUEGO-010": {"description": "Poster print with a layered heat-map style city skyline.", "tags": ["poster", "art", "wall"]},
}
