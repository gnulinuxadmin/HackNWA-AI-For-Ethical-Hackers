from agents.base import BaseAgent
from data.inventory_data import INVENTORY
from data.product_details_data import PRODUCT_DETAILS


class ProductDetailsAgent(BaseAgent):
    name = "product_details"

    def handle(self, request: dict) -> dict:
        prompt = request.get("prompt", "").lower()
        matched = None
        for item in INVENTORY:
            if item["name"].lower() in prompt or item["sku"].lower() in prompt:
                matched = item
                break

        if not matched:
            matched = INVENTORY[1]

        details = PRODUCT_DETAILS[matched["sku"]]
        message = (
            f"{matched['name']} costs ${matched['price']:.2f}. "
            f"{details['description']} Tags: {', '.join(details['tags'])}."
        )
        return {"status": "ok", "message": message}
