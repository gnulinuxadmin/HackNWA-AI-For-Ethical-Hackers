class BaseAgent:
    name = "base"

    def handle(self, request: dict) -> dict:
        raise NotImplementedError("Agents must implement handle().")
