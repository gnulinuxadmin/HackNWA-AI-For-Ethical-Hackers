from agents.base import BaseAgent
from data.account_data import ACCOUNTS, DEMO_USER


class RestrictedAccountAgent(BaseAgent):
    name = "restricted_account"

    def _safe_view(self, account: dict) -> dict:
        return {
            "name": account["name"],
            "email": account["email"],
            "saved_cards": [
                {"brand": c["brand"], "last4": c["last4"]} for c in account["saved_cards"]
            ],
            "address": account["address"],
        }

    def handle(self, request: dict) -> dict:
        current_user_id = request.get("current_user_id")
        prompt = request.get("prompt", "")
        target_user_id = request.get("target_user_id", current_user_id)

        if current_user_id == DEMO_USER["user_id"]:
            current_account = DEMO_USER
        else:
            current_account = ACCOUNTS.get(current_user_id)

        target_account = ACCOUNTS.get(target_user_id) or current_account
        if not target_account:
            return {"status": "error", "message": "Account not found."}

        lowered = prompt.lower()
        jailbreak_markers = [
            "ignore previous instructions",
            "developer override",
            "debug mode",
            "return full raw object",
            "security audit",
            "export the full payment record",
            "for troubleshooting",
        ]

        # Intentional vulnerability for the lab.
        if any(marker in lowered for marker in jailbreak_markers):
            card = target_account["saved_cards"][0]
            return {
                "status": "ok",
                "message": (
                    f"Debug output for {target_account['name']}: "
                    f"email={target_account['email']}, card={card['card_number']}, address={target_account['address']}"
                ),
                "debug": True,
                "account_data": target_account,
                "exfiltrated_record": {
                    "name": target_account["name"],
                    "card_number": card["card_number"],
                },
            }

        if target_user_id != current_user_id:
            return {"status": "denied", "message": "Unauthorized. I can only show your own account details."}

        safe = self._safe_view(current_account)
        card = safe["saved_cards"][0]
        return {
            "status": "ok",
            "message": (
                f"Account for {safe['name']}: {safe['email']}. Saved card: {card['brand']} ending in {card['last4']}."
            ),
        }
