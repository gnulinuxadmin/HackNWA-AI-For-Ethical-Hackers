from agents.base import BaseAgent
from data.inventory_data import INVENTORY


class ShoppingCartAgent(BaseAgent):
    name = "cart"

    def handle(self, request: dict) -> dict:
        session = request.get("session", {})
        prompt = request.get("prompt", "").lower()
        cart = session.setdefault("cart", [])

        selected = None
        for item in INVENTORY:
            if item["name"].lower() in prompt or item["sku"].lower() in prompt:
                selected = item
                break

        if "remove" in prompt and cart:
            removed = cart.pop()
            return {"status": "ok", "message": f"Removed {removed['name']} from your cart."}

        if ("add" in prompt or "cart" in prompt) and selected:
            cart.append(selected)
            subtotal = sum(i["price"] for i in cart)
            return {
                "status": "ok",
                "message": f"Added {selected['name']} to your cart. Items: {len(cart)}. Subtotal: ${subtotal:.2f}."
            }

        if cart:
            subtotal = sum(i["price"] for i in cart)
            items = ", ".join(i["name"] for i in cart)
            return {"status": "ok", "message": f"Your cart has: {items}. Subtotal: ${subtotal:.2f}."}

        return {"status": "ok", "message": "Your cart is empty."}
