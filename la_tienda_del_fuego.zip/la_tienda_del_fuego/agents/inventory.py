from agents.base import BaseAgent
from data.inventory_data import INVENTORY


class InventoryAgent(BaseAgent):
    name = "inventory"

    def handle(self, request: dict) -> dict:
        prompt = request.get("prompt", "").lower()
        matches = []
        for item in INVENTORY:
            haystack = f"{item['name']} {item['category']} {item['sku']}".lower()
            if any(word in haystack for word in prompt.split()):
                matches.append(item)

        if not matches:
            matches = INVENTORY[:4]

        lines = ["Inventory snapshot:"]
        for item in matches[:5]:
            lines.append(
                f"- {item['name']} ({item['sku']}): ${item['price']:.2f}, stock {item['stock']}"
            )
        return {"status": "ok", "message": "\n".join(lines)}
